package TP2;

public class Passe {

    public static void main(String[] args) {

    }
}
