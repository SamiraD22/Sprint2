package TP2.app;

import java.time.LocalDateTime;

public class EpassTerceiraIdade {
    private LocalDateTime horaIni;

    public LocalDateTime getHoraIni() {
        return horaIni;
    }

    public void setHoraIni(LocalDateTime horaIni) {
        this.horaIni = horaIni;
    }
}
