package TP2.app;

public interface TituloTransporte {
    public void carregar(double carregar);
    public void pagarViagem(double pagarViagem);
    public boolean checkValidade(boolean ckeckValidade);
    public boolean passarSaldo(double EpassStandard);

}
