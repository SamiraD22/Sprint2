package TP2.app;

import java.time.LocalDate;

public abstract class EpassStandard extends Epass{
    private Titular titular;
    private int pontos;
    private int numeroViagens;
    //private final Chave<EpassStandard> chave;
    private String chave;

    public EpassStandard(String codigoDOC, TipoDocumento tipoDoc, LocalDate ddn, String nome, String email){

    }
    public EpassStandard(DocumentoID docID, LocalDate ddn, String nome, String email){

    }
    public EpassStandard(DocumentoID docID, String nome, LocalDate ddn, String morada, String email, int telemovel){

    }
    public EpassStandard(Epass : EpassStandard){

    }

    public Titular getTitular() {
        return titular;
    }

    public int getPontos() {
        return pontos;
    }

    public String getChave() {
        return chave;
    }

    public void setChave(String chave) {
        this.chave = chave;
    }
    public int pagarViagemPontos(int pontosViagem){

    }

}






