package TP2.app;

public class EpassFuncionario {
}
