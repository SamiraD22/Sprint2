package TP2.app;

public enum Duracao {
    sete(7,1500);
    tres(3,700);
    um(1,500);
}
