package TP2.app;

public class EpassFestival {
    private double saldoCartaoPagamento;
    private String nomeEvento;

    public EpassFestival(double saldo, String evento){

    }
    public EpassFestival(String evento){

    }
    public EpassFestival(EpassFestival outro){

    }

    public double getSaldoCartaoPagamento() {
        return saldoCartaoPagamento;
    }

    public void setSaldoCartaoPagamento(double saldoCartaoPagamento) {
        this.saldoCartaoPagamento = saldoCartaoPagamento;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }
}
