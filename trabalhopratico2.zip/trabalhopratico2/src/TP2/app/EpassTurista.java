package TP2.app;

public class EpassTurista {
    private Duracao duracao;

    public EpassTurista (Duracao duracao){

    }

    public Duracao getDuracao() {
        return duracao;
    }

    public EpassTurista (EpassTurista outro ){

    }
}
