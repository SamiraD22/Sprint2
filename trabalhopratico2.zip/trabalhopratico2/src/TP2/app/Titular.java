package TP2.app;

import java.time.LocalDate;

public class Titular {
    private final DocumentoID docID;
    private String nome;
    private LocalDate ddn;
    private String morada;
    private String email;
    private int telemovel;

    public Titular(String codigoDoc, TipoDocumento tipoDoc, String nome, LocalDate ddn, String email, int telemovel){
        this.docID = new DocumentoID(codigoDoc, tipoDoc);
        this.nome = nome;
        this.ddn = ddn;
        this.telemovel = telemovel;

    }

    public DocumentoID getDocID() {
        return docID;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getDdn() {
        return ddn;
    }

    public void setDdn(LocalDate ddn) {
        this.ddn = ddn;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTelemovel() {
        return telemovel;
    }

    public void setTelemovel(int telemovel) {
        this.telemovel = telemovel;
    }
}
