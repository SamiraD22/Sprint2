package TP2.app;

public class Chave {
}
