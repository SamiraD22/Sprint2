package TP2.app;

public abstract class PasseSazonal extends Epass{
    private chave chaveValida;

    public chave getChaveValida() {
        return chaveValida;
    }

    public void setChaveValida(chave chaveValida) {
        this.chaveValida = chaveValida;
    }
    public PasseSazonal(){

    }
}
