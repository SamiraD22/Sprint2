package TP2.app;

import java.util.ArrayList;

public class EpassStudent extends EpassStandard {
    private String escola;
    private int anoFrequenta;
    private int viagemFree;
    private ArrayList<Zona>zonas;

    public String getEscola() {
        return escola;
    }

    public void setEscola(String escola) {
        this.escola = escola;
    }

    public int getAnoFrequenta() {
        return anoFrequenta;
    }

    public void setAnoFrequenta(int anoFrequenta) {
        this.anoFrequenta = anoFrequenta;
    }

    public ArrayList<Zona> getZonas() {
        return zonas;
    }
    public EpassStudent(int ano, String escola){

    }
    public EpassStudent(EpassStudent outro){

    }
}
