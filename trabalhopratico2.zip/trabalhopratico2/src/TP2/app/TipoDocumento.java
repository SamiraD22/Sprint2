package TP2.app;

public enum TipoDocumento {
    BI,
    Passaporte,
    TRE,
    CNI;
}
